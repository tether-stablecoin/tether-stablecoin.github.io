<?php
$botToken="5263950781:AAEqmIajYnIbFlFnQlwbwJsqUIe63DEzuEM";
$IdTelegram=array("1967679796"); 
?>
